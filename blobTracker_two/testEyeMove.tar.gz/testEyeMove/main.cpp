#include <iostream>
#include <fstream>
#include <math.h>
#include <vector>
#include <time.h>

#include <yarp/os/all.h>
#include <yarp/sig/all.h>
#include <yarp/dev/all.h>

//#include "unmask.h"
#include "eventCodec.h"
#include "eventBottle.h"
#include "blob_tracker.h"
#include "tracker_pool.h"

//#include "/home/icub/Himanshu_local/iCubFiles/aquilaLite/libraries/iCubMotor/include/iCubMotor.h"
#include "iCubMotor.h"


using namespace aquilacubmotor;

int main(int numArgs, char** args)
{
  // Initial parameters of the Blob Tracker and the Tracker Pool

	bool moveEyes = true;
  yarp::os::Network yarp;

  // We create the port in which we will receive the DVS events
  yarp::os::BufferedPort<yarp::os::Bottle> dvs_port;
  yarp::os::Bottle *evBottle;

  // We set its name
  std::string local_dvs_port_name = "/dvsReadLocal:i";
  (dvs_port).open(local_dvs_port_name.c_str());
  printf("Created port %s to get data from DVS!!\n\n", local_dvs_port_name.c_str());

  ICubMotor *cubMotor = new ICubMotor(false, false);
  cubMotor->start();


  // Variable controlling the loop
  bool run = true;

  // Variables that will hold the coordinates of the collisions

  while(run ){
    evBottle = dvs_port.read();

    if(evBottle){
    	if(moveEyes == true){
      			cubMotor->moveEyes(evBottle->get(0).asInt(), evBottle->get(1).asInt());
//	cubMotor->moveHead(mean_x, mean_y);
       		}
    	}
  }
}
